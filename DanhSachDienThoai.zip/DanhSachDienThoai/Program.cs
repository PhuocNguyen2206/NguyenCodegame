﻿using System;
using System.Collections.Generic;

class Phone
{
    public string Name;
    public int Price;

    public void ShowInfo()
    {
        Console.WriteLine($"Name: {Name}, Price: {Price}");
    }
}

class Program
{
    static void Main()
    {
        List<Phone> phones = new List<Phone>()
        {
            new Phone() { Name = "Cao", Price = 20000 },
            new Phone() { Name = "Phuoc", Price = 15000 },
            new Phone() { Name = "Nguyen", Price = 10000 }
        };

        Console.WriteLine("📱 Danh sách ban đầu:");
        foreach (Phone p in phones)
        {
            p.ShowInfo();
        }

        Phone p1 = phones[0];
        p1.Price = 9999;

        Console.WriteLine("\n📱 Danh sách sau khi thay đổi giá của p1:");
        foreach (Phone p in phones)
        {
            p.ShowInfo();
        }

        
    }
}
